# Enquete_SNCF-Android

Voici un projet Android codé sur en langage Java sur Android studio.
Il permet de réaliser une enquete de satisfaction de SNCF en donnant son avis sur les différentes lignes de RER (A, B, C, D, E)
Vous devez d'abord creer un nouveau projet MySNCFEnquete. Une fois créer votre projet, vous devez inserer le fichier src dans le fichier app (ex : C:\Users\noname\AndroidStudioProjects\MySNCFEnquete\app).
